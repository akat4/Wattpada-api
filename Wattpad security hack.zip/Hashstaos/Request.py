import requests
from API import api_v2, api_v3, api_v4, api_v5

class Request:
    def __init__(self, cookie=''):
        self.cookie = cookie

    async def make_request(self, api, path, params, method='GET'):
        base_url = {
            'api_v2': api_v2,
            'api_v3': api_v3,
            'api_v4': api_v4,
            'api_v5': api_v5
        }
        url = f"{base_url[api]}{path}"
        res = await requests.request(method, url, params=params)
        return res

    async def get(self, url):
        res = await requests.get(url)
        return res.json()
