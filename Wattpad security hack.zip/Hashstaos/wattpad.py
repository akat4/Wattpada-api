from Stories import Stories
from User import User

class Wattpad:
    def __init__(self, cookie=''):
        self.cookie = cookie
        self.Stories = Stories(self.cookie)
        self.User = User(self.cookie)
