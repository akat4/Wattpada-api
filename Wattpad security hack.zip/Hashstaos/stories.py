from Request import Request
from node_html_parser import parse

class Stories(Request):
    async def search(self, query, limit=20, offset=0, mature=True, language='20'):
        params = {
            'query': query,
            'limit': limit,
            'offset': offset,
            'language': language,
            'mature': mature,
            'fields': 'stories(id,title,voteCount,readCount,commentCount,description,completed,mature,cover,url,isPaywalled,length,language(id),user(name),numParts,lastPublishedPart(createDate),promoted,sponsor(name,avatar),tags,tracking(clickUrl,impressionUrl,thirdParty(impressionUrls,clickUrls)),contest(endDate,ctaLabel,ctaURL)),total,tags,nexturl'
        }
        res = await self.make_request('api_v4', 'search/stories', params)
        return await res.json()

    async def next_handler(self, url):
        return await self.get(url)

    async def detail(self, id):
        params = {
            'fields': 'id,title,length,createDate,modifyDate,voteCount,readCount,commentCount,promoted,sponsor,language,user,description,cover,highlight_colour,completed,isPaywalled,categories,numParts,readingPosition,deleted,dateAdded,lastPublishedPart(createDate),tags,copyright,rating,story_text_url(text),,parts(id,title,voteCount,commentCount,videoId,readCount,photoUrl,modifyDate,length,voted,deleted,text_url(text),dedication)'
        }
        res = await self.make_request('api_v3', f'stories/{id}/', params)
        return await res.json()

    async def view_parts(self, id):
        params = {
            'fields': 'id,title,url,modifyDate,wordCount,photoUrl,commentCount,voteCount,readCount,voted,pages,text_url,rating,group(id,title,cover,url,user(username,name,avatar,twitter,authorMessage),rating,parts(title,url,id)),source(url,label)'
        }
        res = await self.make_request('api_v4', f'parts/{id}', params)
        return await res.json()

    async def read(self, id):
        params = {
            'id': id,
            'include_paragraph_id': '1',
            'output': 'json'
        }
        res = await self.make_request('api_v2', 'storytext', params)
        json = await res.json()
        clean = parse(json['text']).text_content()
        return {
            'text': clean,
            'text_hash': json['text_hash']
        }