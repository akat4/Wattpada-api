from Authentication import Authentication

class User(Authentication):
    async def lookup(self, username):
        params = {
            'fields': 'username,description,avatar,name,email,genderCode,language,birthdate,verified,isPrivate,ambassador,is_staff,follower,following,backgroundUrl,votesReceived,numFollowing,numFollowers,createDate,followerRequest,website,facebook,twitter,followingRequest,numStoriesPublished,numLists,location,externalId,programs,showSocialNetwork,verified_email,has_accepted_latest_tos,highlight_colour,isBlockedByCurrentUser'
        }
        res = await self.make_request('api_v3', f'users/{username}', params)
        return await res.json()
