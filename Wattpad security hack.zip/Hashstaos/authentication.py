import requests
from API import api_v4

class Authentication:
    def __init__(self, cookie=''):
        self.cookie = cookie

    async def login(self, username, password):
        params = {
            'type': 'wattpad',
            'username': username,
            'password': password,
            'fields': 'token,ga,user(username,description,avatar,name,email,genderCode,language,birthdate,verified,isPrivate,ambassador,is_staff,follower,following,backgroundUrl,votesReceived,numFollowing,numFollowers,createDate,followerRequest,website,facebook,twitter,followingRequest,numStoriesPublished,numLists,location,externalId,programs,showSocialNetwork,verified_email,has_accepted_latest_tos,language,inbox(unread),has_password,connectedServices'
        }
        res = await self.make_request('api_v4', 'sessions', params, method='POST')
        return await res.json()

    async def make_request(self, api, path, params, method='GET'):
        url = f"{api_v4[api]}{path}"
        res = await requests.request(method, url, params=params)
        return res
